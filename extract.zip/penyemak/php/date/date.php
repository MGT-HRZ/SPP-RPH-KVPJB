<?php

    //  Set the time zone to your local time zone (e.g., 'Asia/Kuala_Lumpur')
    date_default_timezone_set('Asia/Kuala_Lumpur');

    // Get the current date in the format "day/month in num format/year"
    $date = date("d/m/Y");

    // Get the current date in the format "day/Month/year"
    $date_typ2 = date("d M Y");

    // Get the current date in the format "day/FullMonth/year"
    $date_typ3 = date("d F Y");

?>