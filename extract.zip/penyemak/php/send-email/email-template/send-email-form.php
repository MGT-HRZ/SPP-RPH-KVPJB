<?php

    $gmail_Receiver_content_form = '
        <form>
            <p>
                Hello World!
            </p>
        </form>
    ';
