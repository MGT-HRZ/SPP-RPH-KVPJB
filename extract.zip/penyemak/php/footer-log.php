<div>

    <?php if ($page_dir == 'Feedback') { ?>
        <footer class="text-center text-black">

        <!-- Copyright -->
        <div class="text-center mt-3 p-3">
            <a class="text-black" href="#" data-bs-toggle="modal" data-bs-target="#adlog">MEIMLU</a><label>&nbsp;<i class="fa-regular fa-handshake"></i> KVPJB</label>
            &copy; 2023/2024
            <p id="memory">Will Be Always Remembered <i class="fa-solid fa-heart"></i> <a class="text-black" href="#">LUKMAN HAKIM</a></p>
        </div>
        <!-- Copyright -->
        
        </footer>
    <?php } 
    
    else { ?>
        <footer class="text-center text-white">

        <!-- Copyright -->
        <div class="text-center mt-3 p-3">
            <a class="text-white" href="#" data-bs-toggle="modal" data-bs-target="#adlog">MEIMLU</a><label>&nbsp;<i class="fa-regular fa-handshake"></i> KVPJB</label>
            &copy; 2023/2024
            <p id="memory">Will Be Always Remembered <i class="fa-solid fa-heart"></i> <a class="text-white" href="#">LUKMAN HAKIM</a></p>
        </div>
        <!-- Copyright -->
        
        </footer>
    <?php } ?>
            
</div>  