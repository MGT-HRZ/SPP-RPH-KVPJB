<button class="navbar-toggler border-0" id="hamburger" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
    <span><i class="fa-solid fa-bars fa-lg text-white"></i></span>
</button>